export interface Dekoracio {
    id: number;
    nev: string;
    leiras: string;
    ar: number;
    kepUrl: string;
  }
  