import { Dekoracio } from './dekoracio.model';

export interface KosarTetel {

  dekoracio: Dekoracio;
  mennyiseg: number;
}
