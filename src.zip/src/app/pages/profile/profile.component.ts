import { Rendeles } from '../../models/rendeles.model';
import { Component, Injectable } from '@angular/core';
import { Dekoracio } from '../../models/dekoracio.model';
import { KosarTetel } from '../../models/kosar-tetel.model';
import { AuthService, User } from '../../services/auth.service';
import { CapitalizePipe } from '../../pipes/capitalize.pipe';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule, CapitalizePipe],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {
  user: User | null = null;
  newEmail = '';
  currentPassword = '';
  newPassword = '';
  confirmPassword = '';


previousOrders: Rendeles[] = [];

constructor(private authService: AuthService) {
  this.user = this.authService.getLoggedInUser();
  this.previousOrders = this.authService.getPreviousOrders(this.user?.email || '');
}
  updateEmail() {
    if (this.user && this.newEmail) {
      this.authService.updateEmail(this.newEmail);
      this.user.email = this.newEmail;
      this.newEmail = '';
    }
  }

  updatePassword() {
    if (!this.user) return;
    if (this.newPassword !== this.confirmPassword) {
      alert('Az új jelszavak nem egyeznek!');
      return;
    }

    const success = this.authService.updatePassword(this.currentPassword, this.newPassword);
    if (success) {
      this.currentPassword = '';
      this.newPassword = '';
      this.confirmPassword = '';
    } else {
      alert('A jelenlegi jelszó hibás.');
    }
  }
}
